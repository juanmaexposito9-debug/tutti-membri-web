
# Tutti Membri – Deploy Ready

## Pasos para publicar
1. Sube esta carpeta a un repositorio público en GitHub (por ejemplo `tutti-membri-web`).
2. En **Settings → Pages** elige **Deploy from a branch**, Branch **main**, carpeta **/** (root) y guarda.
3. Tu web quedará disponible en: `https://TU_USUARIO.github.io/tutti-membri-web/`.

## Reemplaza estas imágenes por las tuyas reales (mismos nombres):
- img/logo.png
- img/cantera-macael.jpg
- img/azul-alero.jpg
- img/amarillo-aleros.jpg
- img/gris-plata-aleros.jpg
- img/canto-rodado.jpg

## Formulario
Edita `index.html` y pon tu endpoint de Formspree en el atributo `action` del formulario.
